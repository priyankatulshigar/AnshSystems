import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './empoyee.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employees.comonent.html',
  styleUrls: [ './add-employees.component.css' ] 
})
export class AddEmployeeComponent implements OnInit {
	public id: number;
	public name: string;
	public phone: string;
	public postalcode: string;
	public city: string;
	public address1: string;
	public address2: string;
  constructor(private employeeService: EmployeeService, private router: Router) { }

  ngOnInit() {
  }

  addEmployee() {
	console.log('Adding employee')
	this.employeeService.addEmployee(
		{
	  		"id": this.id,
	  	    "name": this.name,
	  		"phone": this.phone,
	  		"address": {
	  			"city": this.city,
	  			"address_line1": this.address1,
	  			"address_line2": this.address2,
	  			"postal_code": this.postalcode
	  		}
	  	}
	)
   this.router.navigate(['/employees'])
  	alert('Employee added')
  }

}