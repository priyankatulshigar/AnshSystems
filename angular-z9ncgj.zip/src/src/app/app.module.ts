import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { Ng2TableModule } from 'ng2-table/ng2-table';
import {HttpClientModule} from '@angular/common/http';
import { EmployeeService } from './empoyee.service';
import { ListEmployeesComponent } from './list-employess.comonent';
import { AddEmployeeComponent } from './add-employees.comonent';
import { EditEmployeeComponent } from './edit-employees.comonent';

const appRoutes: Routes = [
	 { path: 'employees/edit/:id', component: EditEmployeeComponent },
	 { path: 'employees/add', component: AddEmployeeComponent },
	{ path: 'employees', component: ListEmployeesComponent },
  { path: '', component: ListEmployeesComponent }
]
@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpClientModule, Ng2TableModule,
	RouterModule.forRoot(
		appRoutes
	) ],
  declarations: [ AppComponent, HelloComponent, ListEmployeesComponent, AddEmployeeComponent, EditEmployeeComponent ],
  bootstrap:    [ AppComponent ],
  providers: [EmployeeService]
})
export class AppModule { }
