import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http: HttpClient) { }
  employee_data = {
  "data":[
    {
      "id":1,
      "name":"Jhon",
      "phone":"9090909090",
      "address":{
        "city":"Pune",
        "address_line1": "ABC road",
        "address_line2": "XYZ building",
        "postal_code": "12455"
      }
    },
      {
        "id":2,
        "name":"Priya",
        "phone":"AXYZ999999",
        "address":{
          "city":"Solapur",
          "address_line1": "ABC road",
          "address_line2": "XYZ building",
          "postal_code": "12455"
        }
      },
      {
        "id":3,
        "name":"Swapnil",
        "phone":"111111111",
        "address":{
          "city":"Pune",
          "address_line1": "ABC road",
          "address_line2": "XYZ building",
          "postal_code": "12455"
        }
    }
  ]
}

  fetchEmployees() {
    //return this.http.get('../assets/employee.json');
    return this.employee_data;
  }  

  fetchEmployee(id) {
    return this.employee_data['data'].filter(emp =>{
     return (emp.id == id)
    });
  }

  updateEmployee(employee) {
    this.employee_data['data'] = this.employee_data['data'].filter(emp =>{
     return (emp.id != employee.id)
    })
    this.employee_data['data'].push(employee)
  }

  addEmployee(employee) {
	  this.employee_data['data'].push(employee)
  }
}