import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from './empoyee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employees.comonent.html'
})
export class EditEmployeeComponent implements OnInit {
  public id: number;
  public name: string;
  public phone: string;
  public postalcode: string;
  public city: string;
  public address1: string;
  public address2: string;

  constructor( private activeRoute: ActivatedRoute, private employeeService: EmployeeService, private router: Router ) { }

  ngOnInit() {
		this.id = this.activeRoute.snapshot.params['id'];
		var self = this;
     var empData = this.employeeService.fetchEmployees()
     empData['data'].map(row => {
       if(this.id == row.id){
         self.name = row.name;
          self.phone = row.phone;
          self.postalcode = row.address.postal_code;
          self.city = row.address.city;
          self.address1 = row.address.address_line1;
          self.address2 = row.address.address_line2;
       }
			  
		  })		
  }

  UpdateEmployee() {
	  this.employeeService.updateEmployee({
		  "id": this.id,
		  "name": this.name,
		  "phone": this.phone,
		  "address": {
			  "city": this.city,
			  "address_line1": this.address1,
			  "address_line2": this.address2,
			  "postal_code": this.postalcode
		  }
	  })
    this.router.navigate(['/employees'])
  	alert('Employee updated')
    

  }

}